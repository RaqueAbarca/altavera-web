"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, ExternalLink, MapPin, Navigation } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { buildOrderOnTheWayMessage, buildWhatsAppUrl } from "@/lib/whatsapp";
import { playAdminSound } from "@/lib/adminSounds";
import ShoppingList from "@/components/admin/ShoppingList";
import { getMaturityLabel } from "@/lib/maturity";
import { getPaymentMethodLabel } from "@/lib/paymentMethods";
import {
  formatCutoffLabel,
  formatDeliveryDate,
  formatDeliveryDateShort,
  getCostaRicaDateKey,
} from "@/lib/deliverySchedule";
import "../admin.css";

type OrderItem = {
  id: string;
  product_id: number | null;
  product_name: string;
  price: number | string;
  quantity: number | string;
  maturity_preference: string | null;
  category: string | null;
  unit: string | null;
};

type Order = {
  id: string;
  guest_name: string;
  guest_phone: string;
  total: number | string;
  payment_method: string;
  status: string;
  created_at: string;
  customer_notes: string | null;
  latitude: number | string | null;
  longitude: number | string | null;
  address_description: string | null;
  delivery_cycle_id: string | null;
  order_item: OrderItem[];
};

type ShoppingListItem = {
  id: string;
  product_id: number | null;
  product_name: string;
  quantity: number | string;
  unit: string | null;
  maturity_preference: string | null;
  category: string | null;
};

type DeliveryCycle = {
  id: string;
  delivery_date: string;
  cutoff_at: string;
  status: "open" | "closed";
  closed_at: string | null;
  orders: Order[];
  shoppingList: {
    id: string;
    delivery_cycle_id: string;
    created_at: string;
    finalized_at: string;
    shopping_list_items: ShoppingListItem[];
  } | null;
};

type AdminResponse = {
  cycles: DeliveryCycle[];
  legacyOrders: Order[];
  error?: string;
};

type StatusTab = "pending" | "confirmed" | "preparing" | "ready" | "delivered";

const STATUS_TABS: Array<{ key: StatusTab; label: string }> = [
  { key: "pending", label: "Pago por confirmar" },
  { key: "confirmed", label: "Confirmados" },
  { key: "preparing", label: "Preparando" },
  { key: "ready", label: "En camino" },
  { key: "delivered", label: "Entregados" },
];

const PURCHASE_ELIGIBLE_STATUSES = new Set([
  "confirmed",
  "preparing",
  "ready",
  "delivered",
]);

function isPurchaseEligibleOrder(order: Order) {
  return PURCHASE_ELIGIBLE_STATUSES.has(order.status);
}

function belongsToTab(status: string, tab: StatusTab) {
  if (tab === "pending") {
    return status === "pending" || status === "pending_payment";
  }
  return status === tab;
}


function hasDeliveryCoordinates(order: Order) {
  const latitude = Number(order.latitude);
  const longitude = Number(order.longitude);
  return (
    Number.isFinite(latitude) &&
    Number.isFinite(longitude) &&
    !(latitude === 0 && longitude === 0)
  );
}

function googleMapsUrl(order: Order) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${Number(order.latitude)},${Number(order.longitude)}`)}`;
}

function wazeUrl(order: Order) {
  return `https://www.waze.com/ul?ll=${encodeURIComponent(`${Number(order.latitude)},${Number(order.longitude)}`)}&navigate=yes`;
}

function buildLiveShoppingList(orders: Order[]) {
  const map = new Map<
    string,
    {
      name: string;
      quantity: number;
      maturityPreference: string | null;
      category: string | null;
      unit: string | null;
    }
  >();

  orders
    .filter(isPurchaseEligibleOrder)
    .forEach((order) => {
      order.order_item.forEach((item) => {
        const maturityPreference = item.maturity_preference ?? null;
        const unit = item.unit?.trim() || null;
        const key = `${item.product_id ?? item.product_name}::${unit ?? "none"}::${maturityPreference ?? "none"}`;
        const current = map.get(key);

        map.set(key, {
          name: item.product_name,
          quantity: (current?.quantity ?? 0) + Number(item.quantity),
          maturityPreference,
          category: item.category ?? null,
          unit,
        });
      });
    });

  return [...map.values()].sort((a, b) =>
    a.name.localeCompare(b.name, "es")
  );
}

export default function AdminOrdersPage() {
  const [cycles, setCycles] = useState<DeliveryCycle[]>([]);
  const [legacyOrders, setLegacyOrders] = useState<Order[]>([]);
  const [selectedCycleId, setSelectedCycleId] = useState("");
  const [activeTab, setActiveTab] = useState<StatusTab>("pending");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const router = useRouter();

  async function loadData() {
    setLoading(true);
    setError("");

    try {
      const response = await fetch("/api/admin/delivery-cycles", {
        cache: "no-store",
      });
      const data = (await response.json()) as AdminResponse;

      if (response.status === 401 || response.status === 403) {
        router.push("/admin");
        return;
      }

      if (!response.ok) {
        throw new Error(data.error ?? "No se pudo cargar el panel");
      }

      const today = getCostaRicaDateKey();
      const operational = [...data.cycles]
        .filter((cycle) => cycle.delivery_date >= today)
        .sort((a, b) => a.delivery_date.localeCompare(b.delivery_date))
        .slice(0, 3);
      const history = [...data.cycles]
        .filter((cycle) => cycle.delivery_date < today)
        .sort((a, b) => b.delivery_date.localeCompare(a.delivery_date))
        .slice(0, 4);
      const visibleCycles = [...operational, ...history];

      setCycles(visibleCycles);
      setLegacyOrders(data.legacyOrders ?? []);
      setSelectedCycleId((current) => {
        if (visibleCycles.some((cycle) => cycle.id === current)) {
          return current;
        }

        const preferred =
          operational.find((cycle) => cycle.orders.length > 0) ??
          operational.find((cycle) => cycle.status === "open") ??
          visibleCycles[0];

        return preferred?.id ?? "";
      });
    } catch (loadError) {
      setError(
        loadError instanceof Error
          ? loadError.message
          : "No se pudo cargar el panel"
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadData();
  }, []);

  const selectedCycle = useMemo(
    () => cycles.find((cycle) => cycle.id === selectedCycleId) ?? null,
    [cycles, selectedCycleId]
  );

  const visibleOrders = useMemo(
    () =>
      (selectedCycle?.orders ?? []).filter((order) =>
        belongsToTab(order.status, activeTab)
      ),
    [selectedCycle, activeTab]
  );

  const shoppingProducts = useMemo(() => {
    if (!selectedCycle) return [];

    // La lista visible e impresa se reconstruye siempre desde los pedidos del
    // ciclo. Así una lista congelada antigua nunca vuelve a incluir pedidos
    // pendientes de pago que pudieran haberse agregado antes de este cambio.
    return buildLiveShoppingList(selectedCycle.orders);
  }, [selectedCycle]);

  const purchaseOrderCount = useMemo(
    () =>
      (selectedCycle?.orders ?? []).filter(isPurchaseEligibleOrder).length,
    [selectedCycle]
  );

  const pendingPaymentOrderCount = useMemo(
    () =>
      (selectedCycle?.orders ?? []).filter((order) =>
        belongsToTab(order.status, "pending")
      ).length,
    [selectedCycle]
  );

  async function updateStatus(order: Order, status: string) {
    const isGoingOnTheWay = status === "ready";
    const whatsappUrl = isGoingOnTheWay
      ? buildWhatsAppUrl({
          phone: order.guest_phone,
          message: buildOrderOnTheWayMessage({
            customerName: order.guest_name,
            orderId: order.id,
          }),
        })
      : null;

    // Abrimos una pestaña vacía durante el click para evitar que el navegador
    // bloquee WhatsApp por ocurrir después de una operación asíncrona.
    const whatsappWindow = whatsappUrl
      ? window.open("about:blank", "_blank")
      : null;

    try {
      const response = await fetch(
        `/api/admin/orders/${encodeURIComponent(order.id)}/status`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status }),
        }
      );
      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(data.error ?? "No se pudo cambiar el estado del pedido.");
      }

      if (data.email?.status === "failed") {
        console.warn(
          "El estado cambió, pero no se pudo enviar el correo:",
          data.email.reason
        );
      }

      if (status === "confirmed") {
        void playAdminSound("payment-confirmed");
      }

      // Para "En camino" mantenemos WhatsApp como apoyo inmediato. El correo
      // de estado se envía automáticamente desde la ruta del servidor.
      if (isGoingOnTheWay) {
        if (whatsappUrl && whatsappWindow) {
          whatsappWindow.opener = null;
          whatsappWindow.location.href = whatsappUrl;
        } else if (!whatsappUrl) {
          alert(
            "El pedido quedó marcado como En camino, pero no tiene un teléfono válido para abrir WhatsApp."
          );
        } else {
          alert(
            "El pedido quedó marcado como En camino, pero el navegador bloqueó la ventana de WhatsApp."
          );
        }
      }
    } catch (updateError) {
      whatsappWindow?.close();
      alert(
        updateError instanceof Error
          ? updateError.message
          : "No se pudo cambiar el estado del pedido."
      );
      console.error("ERROR CAMBIANDO ESTADO:", updateError);
      return;
    }

    await loadData();
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    window.location.href = "/admin";
  }

  function nextAction(order: Order) {
    if (belongsToTab(order.status, "pending")) {
      return {
        label: "Confirmar pago",
        status: "confirmed",
      };
    }

    if (order.status === "confirmed") {
      return {
        label: "Pasar a preparación",
        status: "preparing",
      };
    }

    if (order.status === "preparing") {
      return {
        label: "Marcar en camino",
        status: "ready",
      };
    }

    if (order.status === "ready") {
      return {
        label: "Marcar como entregado",
        status: "delivered",
      };
    }

    return null;
  }

  if (loading) {
    return (
      <main className="admin-container">
        <p>Cargando pedidos...</p>
      </main>
    );
  }

  return (
    <main className="admin-container orders-admin-page">
      <header className="admin-page-header">
        <div>
          <Link className="admin-back-link" href="/admin/dashboard">
            <ArrowLeft size={17} strokeWidth={2} aria-hidden="true" />
            Volver al panel
          </Link>
          <h1>Panel de pedidos</h1>
          <p>Pedidos organizados por fecha de entrega y estado.</p>
        </div>
        <button className="admin-logout-button" onClick={handleLogout}>
          Cerrar sesión
        </button>
      </header>

      {error && <div className="admin-error-box">{error}</div>}

      {cycles.length === 0 ? (
        <section className="orders-empty-state">
          <h2>No hay ciclos de entrega disponibles</h2>
          <p>Aplica la migración de ciclos de entrega en Supabase y vuelve a cargar.</p>
        </section>
      ) : (
        <>
          <section className="delivery-cycle-picker">
            <div className="delivery-cycle-picker-heading">
              <h2>Entregas</h2>
              <span>Se muestran hasta 3 entregas próximas y las 4 más recientes.</span>
            </div>

            <div className="delivery-cycle-buttons">
              {cycles.map((cycle) => (
                <button
                  key={cycle.id}
                  type="button"
                  className={cycle.id === selectedCycleId ? "active" : ""}
                  onClick={() => {
                    setSelectedCycleId(cycle.id);
                    setActiveTab("pending");
                  }}
                >
                  <strong>{formatDeliveryDateShort(cycle.delivery_date)}</strong>
                  <span>{cycle.status === "open" ? "Recibiendo pedidos" : "Corte realizado"}</span>
                </button>
              ))}
            </div>
          </section>

          {selectedCycle && (
            <>
              <section className="delivery-cycle-summary">
                <div>
                  <span className="delivery-cycle-eyebrow">Entrega seleccionada</span>
                  <h2>{formatDeliveryDate(selectedCycle.delivery_date)}</h2>
                  <p>Corte: {formatCutoffLabel(selectedCycle.cutoff_at)}</p>
                </div>
                <div className={`cycle-status-badge cycle-status-badge--${selectedCycle.status}`}>
                  {selectedCycle.status === "open" ? "Recibiendo pedidos" : "Corte realizado"}
                </div>
              </section>

              <ShoppingList
                products={shoppingProducts}
                title={
                  selectedCycle.shoppingList
                    ? "Lista de compra del corte"
                    : "Vista previa de la lista de compra"
                }
                subtitle={
                  purchaseOrderCount === 0
                    ? "Todavía no hay pedidos con pago confirmado. Los pendientes y cancelados no se incluyen."
                    : `${purchaseOrderCount} ${purchaseOrderCount === 1 ? "pedido con pago confirmado" : "pedidos con pago confirmado"} incluidos.${pendingPaymentOrderCount > 0 ? ` ${pendingPaymentOrderCount} ${pendingPaymentOrderCount === 1 ? "pendiente de pago queda fuera" : "pendientes de pago quedan fuera"}.` : ""} Los cancelados tampoco se incluyen.`
                }
                emptyMessage="Todavía no hay productos de pedidos con pago confirmado para esta entrega."
                printContext={`Entrega: ${formatDeliveryDate(selectedCycle.delivery_date)} · Corte: ${formatCutoffLabel(selectedCycle.cutoff_at)} · Pedidos incluidos: ${purchaseOrderCount} · Solo pagos confirmados`}
              />

              <section className="orders-section">
                <div className="order-status-tabs">
                  {STATUS_TABS.map((tab) => {
                    const count = selectedCycle.orders.filter((order) =>
                      belongsToTab(order.status, tab.key)
                    ).length;

                    return (
                      <button
                        key={tab.key}
                        type="button"
                        className={activeTab === tab.key ? "active" : ""}
                        onClick={() => setActiveTab(tab.key)}
                      >
                        {tab.label}
                        <span>{count}</span>
                      </button>
                    );
                  })}
                </div>

                {visibleOrders.length === 0 ? (
                  <div className="orders-empty-state compact">
                    No hay pedidos en esta etapa.
                  </div>
                ) : (
                  <div className="orders-grid">
                    {visibleOrders.map((order) => {
                      const action = nextAction(order);

                      return (
                        <article className="order-card" key={order.id}>
                          <div className="order-card-heading">
                            <div>
                              <h3>Pedido #{order.id.slice(0, 8)}</h3>
                              <p>{order.guest_name} · {order.guest_phone}</p>
                              <span className="order-payment-method">
                                {getPaymentMethodLabel(order.payment_method)}
                              </span>
                            </div>
                            <strong>₡{Number(order.total).toLocaleString("es-CR")}</strong>
                          </div>

                          {order.customer_notes && (
                            <div className="order-customer-notes">
                              <strong>Notas del cliente</strong>
                              <p>{order.customer_notes}</p>
                            </div>
                          )}

                          {hasDeliveryCoordinates(order) && (
                            <div className="order-delivery-location">
                              <div className="order-delivery-location-copy">
                                <MapPin size={17} aria-hidden="true" />
                                <div>
                                  <strong>Ubicación de entrega</strong>
                                  <p>
                                    {order.address_description?.trim() ||
                                      `${Number(order.latitude).toFixed(5)}, ${Number(order.longitude).toFixed(5)}`}
                                  </p>
                                </div>
                              </div>
                              <div className="order-delivery-location-actions">
                                <a href={wazeUrl(order)} target="_blank" rel="noreferrer">
                                  <Navigation size={15} aria-hidden="true" />
                                  Waze
                                </a>
                                <a href={googleMapsUrl(order)} target="_blank" rel="noreferrer">
                                  <ExternalLink size={15} aria-hidden="true" />
                                  Google Maps
                                </a>
                              </div>
                            </div>
                          )}

                          <ul className="order-products-list">
                            {order.order_item.map((item) => {
                              const maturityLabel = getMaturityLabel(
                                item.maturity_preference
                              );

                              return (
                                <li key={item.id}>
                                  <span>
                                    {item.product_name}
                                    {maturityLabel && (
                                      <small>Maduración: {maturityLabel}</small>
                                    )}
                                  </span>
                                  <strong>
                                    {item.unit
                                      ? `${Number(item.quantity).toLocaleString("es-CR")} ${item.unit}`
                                      : `x ${Number(item.quantity).toLocaleString("es-CR")}`}
                                  </strong>
                                </li>
                              );
                            })}
                          </ul>

                          {action && (
                            <div className="order-actions">
                              <button
                                type="button"
                                onClick={() => updateStatus(order, action.status)}
                              >
                                {action.label}
                              </button>
                            </div>
                          )}
                        </article>
                      );
                    })}
                  </div>
                )}
              </section>
            </>
          )}
        </>
      )}

      {legacyOrders.length > 0 && (
        <details className="legacy-orders">
          <summary>Pedidos anteriores sin fecha de entrega ({legacyOrders.length})</summary>
          <p>
            Son pedidos creados antes de instalar el sistema de cortes. Se conservan en el historial.
          </p>
        </details>
      )}
    </main>
  );
}
