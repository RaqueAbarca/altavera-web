"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import ShoppingList from "@/components/admin/ShoppingList";
import { getMaturityLabel } from "@/lib/maturity";
import { useRouter } from "next/navigation";
import "../admin.css";

type OrderItem = {
  id: string;
  product_name: string;
  price: number;
  quantity: number;
  maturity_preference: string | null;
};

type Order = {
  id: string;
  guest_name: string;
  guest_phone: string;
  total: number;
  status: string;
  created_at: string;
  customer_notes: string | null;
  items: OrderItem[];
};

export default function AdminPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  async function loadOrders() {
    const { data: ordersData, error } = await supabase
      .from("orders")
      .select("*")
      .order("created_at", {
        ascending: false,
      });

    if (error) {
      console.error("ERROR PEDIDOS:", error);
      setLoading(false);
      return;
    }

    const ordersWithItems = await Promise.all(
      (ordersData || []).map(async (order) => {
        const { data: items, error: itemError } = await supabase
          .from("order_item")
          .select("*")
          .eq("order_id", order.id);

        if (itemError) {
          console.error("ERROR ITEMS:", itemError);
        }

        return {
          ...order,
          items: items || [],
        };
      })
    );

    setOrders(ordersWithItems);
    setLoading(false);
  }

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session) {
        router.push("/admin");
        return;
      }

      const {
        data: profile,
        error,
      } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", session.user.id)
        .single();

      if (
        error ||
        !profile ||
        profile.role !== "admin"
      ) {
        router.push("/admin");
        return;
      }

      loadOrders();
    };

    checkAuth();
  }, [router]);

  async function updateStatus(
    order: Order,
    status: string
  ) {
    const { error } = await supabase
      .from("orders")
      .update({ status })
      .eq("id", order.id);

    if (error) {
      console.error(
        "ERROR CAMBIANDO ESTADO:",
        error
      );
      return;
    }

    const { error: functionError } =
      await supabase.functions.invoke(
        "order-status",
        {
          body: {
            orderId: order.id,
            status,
          },
        }
      );

    if (functionError) {
      console.error(
        "ERROR NOTIFICANDO ESTADO:",
        functionError
      );
    }

    await loadOrders();
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    window.location.href = "/admin";
  }

  const shoppingMap = new Map<
    string,
    {
      name: string;
      quantity: number;
      maturityPreference: string | null;
    }
  >();

  orders.forEach((order) => {
    order.items.forEach((item) => {
      const maturityPreference =
        item.maturity_preference ?? null;
      const key = `${item.product_name}::${maturityPreference ?? "none"}`;
      const current = shoppingMap.get(key);

      shoppingMap.set(key, {
        name: item.product_name,
        quantity:
          (current?.quantity ?? 0) + item.quantity,
        maturityPreference,
      });
    });
  });

  const shoppingProducts = [...shoppingMap.values()];

  if (loading) {
    return (
      <main className="admin-container">
        <p>Cargando pedidos...</p>
      </main>
    );
  }

  return (
    <main className="admin-container">
      <header
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "2rem",
        }}
      >
        <h1>Panel de pedidos</h1>
        <button
          onClick={handleLogout}
          style={{
            padding: "0.5rem 1rem",
            backgroundColor: "#dc2626",
            color: "white",
            border: "none",
            borderRadius: "6px",
            cursor: "pointer",
          }}
        >
          Cerrar Sesión
        </button>
      </header>

      <ShoppingList products={shoppingProducts} />

      <section className="orders-section">
        <h2>Pedidos recibidos</h2>

        {orders.length === 0 ? (
          <p>No hay pedidos todavía.</p>
        ) : (
          orders.map((order) => (
            <article
              className="order-card"
              key={order.id}
            >
              <h3>
                Pedido #{order.id.slice(0, 8)}
              </h3>
              <p>Cliente: {order.guest_name}</p>
              <p>Teléfono: {order.guest_phone}</p>

              {order.customer_notes && (
                <div
                  style={{
                    margin: "0.9rem 0",
                    padding: "0.85rem 1rem",
                    background: "#fffaf2",
                    border: "1px solid #f0e3ce",
                    borderRadius: "10px",
                  }}
                >
                  <strong>Notas del cliente</strong>
                  <p style={{ margin: "0.35rem 0 0" }}>
                    {order.customer_notes}
                  </p>
                </div>
              )}

              <h4>Productos</h4>
              {order.items.length === 0 ? (
                <p>Sin productos</p>
              ) : (
                <ul>
                  {order.items.map((item) => {
                    const maturityLabel = getMaturityLabel(
                      item.maturity_preference
                    );

                    return (
                      <li key={item.id}>
                        {item.product_name} x{" "}
                        {item.quantity} - ₡
                        {item.price}
                        {maturityLabel && (
                          <span>
                            {" "}· Maduración: {maturityLabel}
                          </span>
                        )}
                      </li>
                    );
                  })}
                </ul>
              )}

              <p>Total: ₡{order.total}</p>
              <p>Estado: {order.status}</p>

              <div className="order-actions">
                <button
                  onClick={() =>
                    updateStatus(
                      order,
                      "preparing"
                    )
                  }
                >
                  Preparando
                </button>
                <button
                  onClick={() =>
                    updateStatus(order, "ready")
                  }
                >
                  En camino
                </button>
                <button
                  onClick={() =>
                    updateStatus(
                      order,
                      "delivered"
                    )
                  }
                >
                  Entregado
                </button>
              </div>
            </article>
          ))
        )}
      </section>
    </main>
  );
}
