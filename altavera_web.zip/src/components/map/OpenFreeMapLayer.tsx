export { default } from "./AltaveraMapLayer";
